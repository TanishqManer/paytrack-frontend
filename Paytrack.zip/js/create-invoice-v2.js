document.addEventListener("DOMContentLoaded", () => {

  /* =====================================
     PayTrack – Create Invoice (REAL + PDF)
     ===================================== */

  /* ---------- AUTH GUARD ---------- */
  if (!localStorage.getItem("paytrack_token")) {
    window.location.href = "login.html";
    return;
  }

  /* ---------- SETTINGS ---------- */
  const settings =
    JSON.parse(localStorage.getItem("paytrack_settings")) || {};

  const invoiceSettings = settings.invoice || {
    prefix: "INV",
    gstPercent: 0,
    dueDays: 0,
    currency: "₹"
  };

  const paymentSettings = settings.payments || {
    cash: true,
    upi: true,
    bank: false
  };

  /* ---------- DATA ---------- */
  const products = JSON.parse(localStorage.getItem("paytrack_items")) || [];
  let cart = [];

  /* ---------- ELEMENTS ---------- */
  const productGrid = document.getElementById("productGrid");
  const invoiceCart = document.getElementById("invoiceCart");
  const totalAmount = document.getElementById("totalAmount");

  const clientNameInput = document.getElementById("clientName");
  const clientEmailInput = document.getElementById("clientEmail");
  const clientAddressInput = document.getElementById("clientAddress");
  const createInvoiceBtn = document.getElementById("createInvoiceBtn");

  /* ---------- STORAGE ---------- */
  function getInvoices() {
    return JSON.parse(localStorage.getItem("paytrack_invoices")) || [];
  }

  function saveInvoices(invoices) {
    localStorage.setItem("paytrack_invoices", JSON.stringify(invoices));
  }

  /* ---------- PDF GENERATOR ---------- */
  function generateInvoicePDF(invoice) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.setFontSize(18);
    doc.text("INVOICE", 14, 20);

    doc.setFontSize(11);
    doc.text(`Invoice ID: ${invoice.id}`, 14, 30);
    doc.text(`Date: ${new Date(invoice.createdAt).toLocaleDateString()}`, 14, 36);
    doc.text(`Due Date: ${new Date(invoice.dueDate).toLocaleDateString()}`, 14, 42);

    doc.text(`Client: ${invoice.clientName}`, 14, 54);
    if (invoice.clientEmail)
      doc.text(`Email: ${invoice.clientEmail}`, 14, 60);
    if (invoice.clientAddress)
      doc.text(`Address: ${invoice.clientAddress}`, 14, 66);

    const tableData = invoice.items.map(item => [
      item.name,
      item.qty,
      `${invoiceSettings.currency}${item.price}`,
      `${invoiceSettings.currency}${item.price * item.qty}`
    ]);

    doc.autoTable({
      startY: 78,
      head: [["Item", "Qty", "Price", "Total"]],
      body: tableData
    });

    const finalY = doc.lastAutoTable.finalY || 90;

    doc.text(
      `Subtotal: ${invoiceSettings.currency}${invoice.subtotal}`,
      14,
      finalY + 10
    );

    doc.text(
      `GST (${invoice.gstPercent}%): ${invoiceSettings.currency}${(
        invoice.subtotal * invoice.gstPercent / 100
      ).toFixed(2)}`,
      14,
      finalY + 16
    );

    doc.setFontSize(14);
    doc.text(
      `Total: ${invoiceSettings.currency}${invoice.total.toFixed(2)}`,
      14,
      finalY + 26
    );

    const pdfBlob = doc.output("blob");
    const reader = new FileReader();

    return new Promise(resolve => {
      reader.onloadend = () => {
        resolve(reader.result); // base64
      };
      reader.readAsDataURL(pdfBlob);
    });
  }

  /* ---------- RENDER PRODUCTS ---------- */
  function renderProducts() {
    if (!productGrid) return;
    productGrid.innerHTML = "";

    if (products.length === 0) {
      productGrid.innerHTML =
        `<p class="subtitle">No products found. Add items first.</p>`;
      return;
    }

    products.forEach(product => {
      const card = document.createElement("div");
      card.className = "product-card";

      card.innerHTML = `
        <div class="product-image">
          ${
            product.image
              ? `<img src="${product.image}" alt="${product.name}">`
              : `<span class="subtitle">No Image</span>`
          }
        </div>

        <div class="product-body">
          <h4>${product.name}</h4>
          <div class="product-price">
            ${invoiceSettings.currency}${product.price}
          </div>
        </div>

        <div class="product-actions">
          <button class="btn-secondary">Add to Cart</button>
        </div>
      `;

      card.querySelector("button").addEventListener("click", () => {
        addToCart(product);
      });

      productGrid.appendChild(card);
    });
  }

  /* ---------- ADD TO CART ---------- */
  function addToCart(product) {
    const existing = cart.find(item => item.id === product.id);

    if (existing) {
      existing.qty += 1;
    } else {
      cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        qty: 1
      });
    }

    renderCart();
  }

  /* ---------- RENDER CART ---------- */
  function renderCart() {
    if (!invoiceCart) return;
    invoiceCart.innerHTML = "";

    if (cart.length === 0) {
      invoiceCart.innerHTML =
        `<p class="subtitle">No items added.</p>`;
      totalAmount.textContent = `${invoiceSettings.currency}0`;
      return;
    }

    cart.forEach(item => {
      const row = document.createElement("div");
      row.className = "cart-item";

      row.innerHTML = `
        <div>
          <strong>${item.name}</strong>
          <div class="subtitle">
            ${invoiceSettings.currency}${item.price}
          </div>
        </div>

        <div class="cart-qty">
          <button data-action="dec">−</button>
          <span>${item.qty}</span>
          <button data-action="inc">+</button>
        </div>

        <div>
          ${invoiceSettings.currency}${item.price * item.qty}
        </div>
      `;

      const [decBtn, incBtn] = row.querySelectorAll("button");

      incBtn.onclick = () => {
        item.qty++;
        renderCart();
      };

      decBtn.onclick = () => {
        item.qty--;
        if (item.qty <= 0) {
          cart = cart.filter(i => i.id !== item.id);
        }
        renderCart();
      };

      invoiceCart.appendChild(row);
    });

    calculateTotal();
  }

  /* ---------- TOTAL + GST ---------- */
  function calculateTotal() {
    const subtotal = cart.reduce(
      (sum, item) => sum + item.price * item.qty,
      0
    );

    const gstAmount =
      subtotal * (invoiceSettings.gstPercent / 100);

    const total = subtotal + gstAmount;

    totalAmount.textContent =
      `${invoiceSettings.currency}${total.toFixed(2)}`;

    return total;
  }

  /* ---------- CREATE & SAVE INVOICE + PDF ---------- */
  if (createInvoiceBtn) {
    createInvoiceBtn.addEventListener("click", async () => {

      if (cart.length === 0) {
        alert("Add at least one item to create invoice");
        return;
      }

      const clientName = clientNameInput.value.trim();
      if (!clientName) {
        alert("Client name is required");
        return;
      }

      const invoices = getInvoices();

      const invoiceId =
        `${invoiceSettings.prefix}-${Date.now()}`;

      const newInvoice = {
        id: invoiceId,
        clientName,
        clientEmail: clientEmailInput.value.trim(),
        clientAddress: clientAddressInput.value.trim(),

        items: cart,
        subtotal: cart.reduce(
          (sum, item) => sum + item.price * item.qty,
          0
        ),

        gstPercent: invoiceSettings.gstPercent,
        total: calculateTotal(),

        status: "pending",
        paymentMethod: null,

        createdAt: new Date().toISOString(),
        dueDate: new Date(
          Date.now() + invoiceSettings.dueDays * 86400000
        ).toISOString()
      };

      /* ---------- PDF GENERATION ---------- */
      const pdfBase64 = await generateInvoicePDF(newInvoice);
      newInvoice.pdfBase64 = pdfBase64;
      newInvoice.pdfFileName = `${invoiceId}.pdf`;

      invoices.unshift(newInvoice);
      saveInvoices(invoices);

      alert("Invoice created & PDF generated ✅");

      cart = [];
      renderCart();
      totalAmount.textContent =
        `${invoiceSettings.currency}0`;

      clientNameInput.value = "";
      clientEmailInput.value = "";
      clientAddressInput.value = "";
    });
  }

  /* ---------- INIT ---------- */
  renderProducts();
  renderCart();

});
