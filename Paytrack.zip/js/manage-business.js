document.addEventListener("DOMContentLoaded", () => {

  if (!localStorage.getItem("paytrack_token")) {
    location.href = "login.html";
    return;
  }

  /* ---------- STORAGE ---------- */
  const KEY = "paytrack_business";

  const getBusiness = () =>
    JSON.parse(localStorage.getItem(KEY)) || { saved: false };

  const saveBusiness = (data) =>
    localStorage.setItem(KEY, JSON.stringify(data));

  let business = getBusiness();

  /* ---------- ELEMENTS ---------- */
  const nameEl = document.getElementById("businessName");
  const addressEl = document.getElementById("businessAddress");
  const emailEl = document.getElementById("businessEmail");
  const phoneEl = document.getElementById("businessPhone");

  const logoInput = document.getElementById("logoInput");
  const stampInput = document.getElementById("stampInput");

  const logoCard = document.getElementById("logoCard");
  const stampCard = document.getElementById("stampCard");

  const logoPreview = document.getElementById("logoPreview");
  const stampPreview = document.getElementById("stampPreview");

  const saveBtn = document.getElementById("saveBtn");

  let logoFile = null;
  let stampFile = null;

  /* ---------- LOAD ---------- */
  function loadData() {
    if (!business.saved) return;

    nameEl.value = business.name || "";
    addressEl.value = business.address || "";
    emailEl.value = business.email || "";
    phoneEl.value = business.phone || "";

    if (business.logo) {
      logoPreview.src = business.logo;
      logoCard.classList.add("has-image");
    }

    if (business.stamp) {
      stampPreview.src = business.stamp;
      stampCard.classList.add("has-image");
    }

    lockForm(true);
  }

  function lockForm(lock) {
    [nameEl, addressEl, emailEl, phoneEl].forEach(i => i.disabled = lock);
    saveBtn.textContent = lock ? "Update Details" : "Save Business Details";
  }

  /* ---------- UPLOAD ---------- */
  logoCard.onclick = () => !business.saved && logoInput.click();
  stampCard.onclick = () => !business.saved && stampInput.click();

  logoInput.onchange = () => {
    logoFile = logoInput.files[0];
    if (!logoFile) return;
    logoPreview.src = URL.createObjectURL(logoFile);
    logoCard.classList.add("has-image");
  };

  stampInput.onchange = () => {
    stampFile = stampInput.files[0];
    if (!stampFile) return;
    stampPreview.src = URL.createObjectURL(stampFile);
    stampCard.classList.add("has-image");
  };

  /* ---------- SAVE ---------- */
  saveBtn.onclick = async () => {

    if (business.saved) {
      business.saved = false;
      saveBusiness(business);
      lockForm(false);
      return;
    }

    if (!nameEl.value.trim()) {
      alert("Business name is required");
      return;
    }

    saveBtn.disabled = true;
    saveBtn.textContent = "Saving...";

    business = {
      saved: true,
      name: nameEl.value.trim(),
      address: addressEl.value.trim(),
      email: emailEl.value.trim(),
      phone: phoneEl.value.trim(),
      logo: logoFile ? await toBase64(logoFile) : business.logo,
      stamp: stampFile ? await toBase64(stampFile) : business.stamp
    };

    saveBusiness(business);
    lockForm(true);

    saveBtn.disabled = false;
  };

  loadData();
});

/* ---------- BASE64 ---------- */
function toBase64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}
