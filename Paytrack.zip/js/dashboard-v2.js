document.addEventListener("DOMContentLoaded", () => {

  /* ================================
     AUTH GUARD
     ================================ */
  if (!localStorage.getItem("paytrack_token")) {
    window.location.href = "login.html";
    return;
  }

  /* ================================
     ELEMENTS
     ================================ */
  const avatar = document.querySelector(".avatar");
  const profileMenu = document.querySelector(".profile-menu");
  const profileEmailEl = document.querySelector(".profile-email");

  const businessWrap = document.getElementById("businessBrandWrap");
  const businessLogoEl = document.getElementById("businessLogoHeader");
  const businessNameEl = document.getElementById("businessNameHeader");

  const statCards = document.querySelectorAll(".stat-card h2");
  const dashboardPanel = document.querySelector(".panel");
  const searchInput = document.querySelector(".nav-center input");
  const viewAllLink = document.querySelector(".panel-header .link");
  const createInvoiceBtn = document.querySelector(".btn-primary");

  /* ================================
     USER INFO
     ================================ */
  const userEmail = localStorage.getItem("paytrack_user");

  if (avatar && userEmail) {
    avatar.textContent = userEmail.charAt(0).toUpperCase();
  }

  if (profileEmailEl && userEmail) {
    profileEmailEl.textContent = userEmail;
  }

  /* ================================
     BUSINESS BRANDING (SOURCE: paytrack_business)
     ================================ */
  function loadBusinessBranding() {
    const business =
      JSON.parse(localStorage.getItem("paytrack_business")) || {};

    if (!business.saved) {
      businessWrap.classList.add("hidden");
      return;
    }

    businessWrap.classList.remove("hidden");

    if (businessNameEl) {
      businessNameEl.textContent = business.name || "";
    }

    if (businessLogoEl && business.logo) {
      businessLogoEl.src = business.logo;
      businessLogoEl.style.display = "block";
    } else if (businessLogoEl) {
      businessLogoEl.style.display = "none";
    }
  }

  /* INITIAL LOAD */
  loadBusinessBranding();

  /* RE-SYNC WHEN COMING BACK */
  window.addEventListener("focus", loadBusinessBranding);

  /* RE-SYNC WHEN STORAGE CHANGES */
  window.addEventListener("storage", (e) => {
    if (e.key === "paytrack_business") {
      loadBusinessBranding();
    }
  });

  /* ================================
     PROFILE MENU
     ================================ */
  if (avatar && profileMenu) {
    avatar.addEventListener("click", (e) => {
      e.stopPropagation();
      profileMenu.classList.toggle("hidden");
    });

    document.addEventListener("click", (e) => {
      if (!profileMenu.contains(e.target) && !avatar.contains(e.target)) {
        profileMenu.classList.add("hidden");
      }
    });
  }

  document.querySelectorAll(".menu-item").forEach(btn => {
    btn.addEventListener("click", () => {
      const action = btn.dataset.action;

      if (action === "profile") {
        location.href = "profile.html";
      }

      if (action === "settings") {
        location.href = "settings.html";
      }

      if (action === "manage-business") {
        location.href = "manage-business.html";
      }

      if (action === "logout") {
        localStorage.clear();
        location.href = "login.html";
      }

      profileMenu.classList.add("hidden");
    });
  });

  /* ================================
     THEME
     ================================ */
  if (localStorage.getItem("paytrack_theme") === "dark") {
    document.body.classList.add("dark");
  }

  /* ================================
     NAV
     ================================ */
  if (createInvoiceBtn) {
    createInvoiceBtn.onclick = () => {
      location.href = "create-invoice-v2.html";
    };
  }

  if (viewAllLink) {
    viewAllLink.onclick = (e) => {
      e.preventDefault();
      location.href = "view-invoices.html";
    };
  }

  /* ================================
     STORAGE HELPERS
     ================================ */
  const getInvoices = () =>
    JSON.parse(localStorage.getItem("paytrack_invoices")) || [];

  const getClients = () =>
    JSON.parse(localStorage.getItem("paytrack_clients")) || [];

  /* ================================
     STATS
     ================================ */
  function updateStats() {
    const invoices = getInvoices();
    const clients = getClients();

    let totalRevenue = 0;
    let paidCount = 0;
    let pendingAmount = 0;

    invoices.forEach(inv => {
      const total = Number(inv.total) || 0;
      totalRevenue += total;

      if (inv.status === "paid") {
        paidCount++;
      } else {
        pendingAmount += total;
      }
    });

    if (statCards.length === 4) {
      statCards[0].textContent = `₹${totalRevenue}`;
      statCards[1].textContent = paidCount;
      statCards[2].textContent = `₹${pendingAmount}`;
      statCards[3].textContent = clients.length;
    }
  }

  /* ================================
     RECENT INVOICES
     ================================ */
  function renderRecentInvoices(list) {
    dashboardPanel
      .querySelectorAll(".invoice-row, .empty-state")
      .forEach(el => el.remove());

    const invoices = (list || getInvoices()).slice(0, 3);

    if (invoices.length === 0) {
      const empty = document.createElement("p");
      empty.className = "muted empty-state";
      empty.textContent = "No invoices found.";
      dashboardPanel.appendChild(empty);
      return;
    }

    invoices.forEach(inv => {
      const row = document.createElement("div");
      row.className = "invoice-row";
      row.innerHTML = `
        <span>${inv.id}</span>
        <span class="muted">${inv.clientName || "-"}</span>
        <span class="${inv.status === "paid" ? "paid" : "pending"}">
          ${inv.status.toUpperCase()}
        </span>
        <span>₹${inv.total}</span>
      `;
      dashboardPanel.appendChild(row);
    });
  }

  /* ================================
     SEARCH
     ================================ */
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      const q = e.target.value.trim().toLowerCase();
      if (!q) {
        renderRecentInvoices();
        return;
      }

      const filtered = getInvoices().filter(inv =>
        inv.id.toLowerCase().includes(q) ||
        (inv.clientName && inv.clientName.toLowerCase().includes(q)) ||
        inv.status.toLowerCase().includes(q)
      );

      renderRecentInvoices(filtered);
    });
  }

  /* ================================
     INSIGHTS
     ================================ */
  function updateInsights() {
    const pending = getInvoices().filter(i => i.status !== "paid").length;
    const alertText = document.querySelector(".alert-text");

    if (alertText) {
      alertText.textContent =
        pending > 0
          ? `${pending} invoices are pending`
          : "All invoices are paid 🎉";
    }
  }

  /* ================================
     INIT
     ================================ */
  updateStats();
  renderRecentInvoices();
  updateInsights();

});
