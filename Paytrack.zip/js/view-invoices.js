document.addEventListener("DOMContentLoaded", () => {

  /* =====================================
     PayTrack – View Invoices (PDF BRANDED)
     ===================================== */

  /* ---------- AUTH ---------- */
  if (!localStorage.getItem("paytrack_token")) {
    window.location.href = "login.html";
    return;
  }

  /* ---------- ELEMENTS ---------- */
  const invoiceList = document.getElementById("invoiceList");

  /* ---------- STORAGE ---------- */
  function getInvoices() {
    return JSON.parse(localStorage.getItem("paytrack_invoices")) || [];
  }

  function saveInvoices(invoices) {
    localStorage.setItem("paytrack_invoices", JSON.stringify(invoices));
  }

  function getSettings() {
    return JSON.parse(localStorage.getItem("paytrack_settings")) || {};
  }

  const settings = getSettings();
  const business = settings.business || {};
  const invoiceSettings = settings.invoice || { currency: "₹" };
  const payments = settings.payments || {};

  /* =====================================
     PDF GENERATION (BRANDED)
     ===================================== */
  async function downloadPDF(invoice) {

    if (!window.jspdf || !window.jspdf.jsPDF) {
      alert("PDF library not loaded");
      return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF("p", "mm", "a4");

    let cursorY = 20;

    /* ---------- LOGO ---------- */
    if (business.logoBase64) {
      doc.addImage(
        business.logoBase64,
        "PNG",
        14,
        cursorY,
        30,
        30
      );
    }

    /* ---------- BUSINESS INFO ---------- */
    doc.setFontSize(14);
    doc.text(business.name || "Business Name", 50, cursorY + 8);

    doc.setFontSize(10);
    if (business.address) {
      doc.text(business.address, 50, cursorY + 14);
    }
    if (business.email) {
      doc.text(`Email: ${business.email}`, 50, cursorY + 20);
    }
    if (business.phone) {
      doc.text(`Phone: ${business.phone}`, 50, cursorY + 26);
    }

    cursorY += 40;

    /* ---------- INVOICE HEADER ---------- */
    doc.setFontSize(18);
    doc.text("INVOICE", 14, cursorY);

    doc.setFontSize(11);
    doc.text(`Invoice ID: ${invoice.id}`, 14, cursorY + 10);
    doc.text(`Date: ${new Date(invoice.createdAt).toLocaleDateString()}`, 14, cursorY + 16);

    doc.text(`Bill To: ${invoice.clientName}`, 120, cursorY + 10);
    if (invoice.clientEmail) {
      doc.text(invoice.clientEmail, 120, cursorY + 16);
    }

    cursorY += 26;

    /* ---------- ITEMS TABLE ---------- */
    const tableData = invoice.items.map(item => [
      item.name,
      item.qty,
      `${invoiceSettings.currency}${item.price}`,
      `${invoiceSettings.currency}${item.price * item.qty}`
    ]);

    doc.autoTable({
      startY: cursorY,
      head: [["Item", "Qty", "Price", "Total"]],
      body: tableData,
      theme: "grid",
      styles: { fontSize: 10 },
      headStyles: { fillColor: [37, 99, 235] }
    });

    cursorY = doc.lastAutoTable.finalY + 10;

    /* ---------- TOTAL ---------- */
    doc.setFontSize(12);
    doc.text(
      `Total Amount: ${invoiceSettings.currency}${invoice.total}`,
      14,
      cursorY
    );

    cursorY += 14;

    /* ---------- PAYMENT STATUS ---------- */
    doc.setFontSize(11);
    doc.text(`Status: ${invoice.status.toUpperCase()}`, 14, cursorY);

    if (invoice.paymentMethod) {
      doc.text(`Payment Method: ${invoice.paymentMethod}`, 14, cursorY + 6);
    }

    /* ---------- STAMP / SIGNATURE (PAID ONLY) ---------- */
    if (invoice.status === "paid" && business.stampBase64) {
      doc.addImage(
        business.stampBase64,
        "PNG",
        140,
        cursorY - 6,
        40,
        40
      );

      doc.text("Authorized Signature", 140, cursorY + 36);
    }

    /* ---------- SAVE PDF ---------- */
    const pdfBlob = doc.output("blob");
    const reader = new FileReader();

    reader.onloadend = () => {
      invoice.pdfBase64 = reader.result;
      invoice.pdfFileName = `${invoice.id}.pdf`;

      const invoices = getInvoices().map(inv =>
        inv.id === invoice.id ? invoice : inv
      );
      saveInvoices(invoices);

      const link = document.createElement("a");
      link.href = reader.result;
      link.download = invoice.pdfFileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };

    reader.readAsDataURL(pdfBlob);
  }

  /* =====================================
     RENDER INVOICES
     ===================================== */
  function renderInvoices() {
    const invoices = getInvoices();
    invoiceList.innerHTML = "";

    if (!invoices.length) {
      invoiceList.innerHTML = `<div class="empty-state">No invoices found.</div>`;
      return;
    }

    invoices.forEach(invoice => {
      const row = document.createElement("div");
      row.className = "invoice-row invoice-table";

      const paymentOptions = [];
      if (payments.cash) paymentOptions.push("Cash");
      if (payments.upi) paymentOptions.push("UPI");
      if (payments.bank) paymentOptions.push("Bank");

      row.innerHTML = `
        <span>${invoice.id}</span>
        <span>${invoice.clientName}</span>
        <span>${invoiceSettings.currency}${invoice.total}</span>

        <span>
          <span class="status ${invoice.status}">
            ${invoice.status.toUpperCase()}
          </span>
        </span>

        <span>${invoice.paymentMethod || "-"}</span>

        <span class="actions">
          ${
            invoice.status !== "paid" && paymentOptions.length
              ? `<select class="payment-select">
                  <option value="">Mark Paid</option>
                  ${paymentOptions.map(p => `<option value="${p}">${p}</option>`).join("")}
                </select>`
              : ""
          }
          <button class="btn-small pdf-btn">PDF</button>
          <button class="btn-small danger delete-btn">Delete</button>
        </span>
      `;

      const paymentSelect = row.querySelector(".payment-select");
      if (paymentSelect) {
        paymentSelect.addEventListener("change", () => {
          invoice.status = "paid";
          invoice.paymentMethod = paymentSelect.value;
          invoice.paidAt = new Date().toISOString();
          saveInvoices(invoices);
          renderInvoices();
        });
      }

      row.querySelector(".pdf-btn").onclick = () => downloadPDF(invoice);

      row.querySelector(".delete-btn").onclick = () => {
        if (confirm("Delete this invoice?")) {
          saveInvoices(invoices.filter(inv => inv.id !== invoice.id));
          renderInvoices();
        }
      };

      invoiceList.appendChild(row);
    });
  }

  /* ---------- THEME ---------- */
  if (settings.appearance?.theme === "dark") {
    document.body.classList.add("dark");
  }

  /* ---------- INIT ---------- */
  renderInvoices();

});
