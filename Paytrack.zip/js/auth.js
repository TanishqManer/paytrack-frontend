/* ============================
   PayTrack - Auth Logic
   Backend-ready JavaScript
   ============================ */

// TEMP API BASE (will be replaced later)
const API_BASE_URL = "http://localhost:5000/api";

/* ============================
   LOGIN
   ============================ */
const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value.trim();

        if (!email || !password) {
            alert("Please fill all fields");
            return;
        }

        // 🔌 Backend integration placeholder
        console.log("LOGIN DATA", { email, password });

        // TEMP SUCCESS FLOW
        localStorage.setItem("paytrack_token", "dummy-jwt-token");
        localStorage.setItem("paytrack_user", email);

        window.location.href = "dashboard.html";
    });
}

/* ============================
   REGISTER
   ============================ */
const registerForm = document.getElementById("registerForm");

if (registerForm) {
    registerForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value.trim();
        const confirmPassword = document.getElementById("confirmPassword").value.trim();

        if (!name || !email || !password || !confirmPassword) {
            alert("Please fill all fields");
            return;
        }

        if (password !== confirmPassword) {
            alert("Passwords do not match");
            return;
        }

        // 🔌 Backend integration placeholder
        console.log("REGISTER DATA", { name, email, password });

        // TEMP SUCCESS FLOW
        localStorage.setItem("paytrack_token", "dummy-jwt-token");
        localStorage.setItem("paytrack_user", email);

        window.location.href = "dashboard-v2.html";
    });
}
