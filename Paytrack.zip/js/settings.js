document.addEventListener("DOMContentLoaded", () => {

  /* ===============================
     AUTH GUARD
     =============================== */
  if (!localStorage.getItem("paytrack_token")) {
    window.location.href = "login.html";
    return;
  }

  /* ===============================
     STORAGE HELPERS
     =============================== */
  function getSettings() {
    return JSON.parse(localStorage.getItem("paytrack_settings")) || {
      appearance: {
        theme: "light"
      },
      invoice: {
        prefix: "INV",
        gstPercent: 18,
        dueDays: 15,
        currency: "₹"
      },
      payments: {
        cash: true,
        upi: false,
        bank: false,
        upiId: "",
        bankDetails: ""
      }
    };
  }

  function saveSettings(settings) {
    localStorage.setItem("paytrack_settings", JSON.stringify(settings));
  }

  const settings = getSettings();

  /* ===============================
     APPEARANCE (DARK MODE)
     =============================== */
  const darkToggle = document.getElementById("darkModeToggle");

  if (settings.appearance.theme === "dark") {
    document.body.classList.add("dark");
    if (darkToggle) darkToggle.checked = true;
  }

  if (darkToggle) {
    darkToggle.addEventListener("change", () => {
      document.body.classList.toggle("dark");

      settings.appearance.theme =
        document.body.classList.contains("dark")
          ? "dark"
          : "light";

      saveSettings(settings);
      toast("Appearance saved");
    });
  }

  /* ===============================
     INVOICE DEFAULTS
     =============================== */
  const invoicePrefix = document.getElementById("invoicePrefix");
  const gstPercent = document.getElementById("gstPercent");
  const dueDays = document.getElementById("dueDays");
  const currency = document.getElementById("currency");
  const saveInvoiceBtn = document.getElementById("saveInvoiceSettings");

  if (invoicePrefix) invoicePrefix.value = settings.invoice.prefix;
  if (gstPercent) gstPercent.value = settings.invoice.gstPercent;
  if (dueDays) dueDays.value = settings.invoice.dueDays;
  if (currency) currency.value = settings.invoice.currency;

  if (saveInvoiceBtn) {
    saveInvoiceBtn.addEventListener("click", () => {
      settings.invoice.prefix = invoicePrefix.value.trim() || "INV";
      settings.invoice.gstPercent = Number(gstPercent.value) || 0;
      settings.invoice.dueDays = Number(dueDays.value) || 0;
      settings.invoice.currency = currency.value;

      saveSettings(settings);
      buttonConfirm(saveInvoiceBtn, "Saved ✓");
    });
  }

  /* ===============================
     PAYMENT METHODS
     =============================== */
  const payCash = document.getElementById("payCash");
  const payUpi = document.getElementById("payUpi");
  const payBank = document.getElementById("payBank");
  const upiId = document.getElementById("upiId");
  const bankDetails = document.getElementById("bankDetails");
  const savePaymentBtn = document.getElementById("savePaymentSettings");

  if (payCash) payCash.checked = settings.payments.cash;
  if (payUpi) payUpi.checked = settings.payments.upi;
  if (payBank) payBank.checked = settings.payments.bank;
  if (upiId) upiId.value = settings.payments.upiId;
  if (bankDetails) bankDetails.value = settings.payments.bankDetails;

  if (savePaymentBtn) {
    savePaymentBtn.addEventListener("click", () => {
      settings.payments.cash = payCash.checked;
      settings.payments.upi = payUpi.checked;
      settings.payments.bank = payBank.checked;
      settings.payments.upiId = upiId.value.trim();
      settings.payments.bankDetails = bankDetails.value.trim();

      saveSettings(settings);
      buttonConfirm(savePaymentBtn, "Saved ✓");
    });
  }

});

/* ===============================
   UI HELPERS
   =============================== */
function buttonConfirm(btn, text) {
  const original = btn.textContent;
  btn.textContent = text;
  btn.disabled = true;

  setTimeout(() => {
    btn.textContent = original;
    btn.disabled = false;
  }, 1400);
}

function toast(message) {
  const t = document.createElement("div");
  t.textContent = message;
  t.style.position = "fixed";
  t.style.bottom = "20px";
  t.style.right = "20px";
  t.style.background = "#2563eb";
  t.style.color = "#fff";
  t.style.padding = "10px 14px";
  t.style.borderRadius = "10px";
  t.style.fontSize = "14px";
  t.style.zIndex = "9999";

  document.body.appendChild(t);

  setTimeout(() => t.remove(), 1500);
}
