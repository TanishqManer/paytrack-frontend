/* =====================================
   PayTrack – View Invoices Logic (Payments)
   ===================================== */

/* ---------- AUTH GUARD ---------- */
if (!localStorage.getItem("paytrack_token")) {
  window.location.href = "../login.html";
}

/* ---------- ELEMENTS ---------- */
const invoiceList = document.getElementById("invoiceList");

/* ---------- STORAGE HELPERS ---------- */
function getInvoices() {
  return JSON.parse(localStorage.getItem("paytrack_invoices")) || [];
}

function saveInvoices(invoices) {
  localStorage.setItem("paytrack_invoices", JSON.stringify(invoices));
}

/* ---------- RENDER INVOICES ---------- */
function renderInvoices() {
  const invoices = getInvoices();
  invoiceList.innerHTML = "";

  if (invoices.length === 0) {
    invoiceList.innerHTML = `<p class="subtitle">No invoices found.</p>`;
    return;
  }

  invoices.forEach(invoice => {
    const row = document.createElement("div");
    row.className = "invoice-row";

    let actionHTML = "";

    // If invoice is pending → show payment options
    if (invoice.status === "pending") {
      actionHTML = `
        <button class="pay-btn cash" data-id="${invoice.id}" data-method="cash">
          Paid (Cash)
        </button>
        <button class="pay-btn upi" data-id="${invoice.id}" data-method="upi">
          Paid (UPI)
        </button>
        <button class="delete-btn" data-id="${invoice.id}">
          Delete
        </button>
      `;
    } else {
      // If invoice is paid → show info
      actionHTML = `
        <span class="muted">
          Paid via ${invoice.paymentMethod?.toUpperCase() || "—"}
        </span>
        <button class="delete-btn" data-id="${invoice.id}">
          Delete
        </button>
      `;
    }

    row.innerHTML = `
      <span>${invoice.id}</span>
      <span>${invoice.clientName || "-"}</span>
      <span>₹${invoice.total}</span>
      <span>
        <span class="status ${invoice.status}">
          ${invoice.status.toUpperCase()}
        </span>
      </span>
      <span>${actionHTML}</span>
    `;

    invoiceList.appendChild(row);
  });

  attachActionHandlers();
}

/* ---------- ACTION HANDLERS ---------- */
function attachActionHandlers() {
  // Delete
  document.querySelectorAll(".delete-btn").forEach(btn => {
    btn.onclick = () => {
      deleteInvoice(btn.dataset.id);
    };
  });

  // Mark as Paid
  document.querySelectorAll(".pay-btn").forEach(btn => {
    btn.onclick = () => {
      markAsPaid(btn.dataset.id, btn.dataset.method);
    };
  });
}

/* ---------- MARK AS PAID ---------- */
function markAsPaid(id, method) {
  const invoices = getInvoices();
  const invoice = invoices.find(inv => inv.id === id);

  if (!invoice) return;

  invoice.status = "paid";
  invoice.paymentMethod = method; // cash | upi
  invoice.paidAt = new Date().toISOString();

  saveInvoices(invoices);
  renderInvoices();
}

/* ---------- DELETE ---------- */
function deleteInvoice(id) {
  if (!confirm("Delete this invoice permanently?")) return;

  let invoices = getInvoices();
  invoices = invoices.filter(inv => inv.id !== id);
  saveInvoices(invoices);
  renderInvoices();
}

/* ---------- INIT ---------- */
renderInvoices();
